# OmniEvent - Event Planning & Platform Analyzer
### College Experiment / Project on Event Planning & Event Platforms

**Candidate Name:** Kavya  
**Roll Number:** 24BDA70266  
**Class / Batch:** 24BDS-4NTPP:A  
**Session:** 2026  

---

## 🎯 Project Objective & Aim
The primary aim of this experiment is to design, implement, and benchmark an end-to-end **Event Planning Platform** capable of:
1. Discovering, categorizing, and managing **7 diverse event paradigms**:
   - 💍 Weddings
   - 🎂 Birthday Parties
   - 💼 Corporate Events & Conferences
   - 🎓 College Events & Hackathons
   - 🎸 Concerts & Music Festivals
   - 🎤 Seminars & Conferences
   - 🥂 Private Parties & VIP Galas
2. Providing a systematic, comparative benchmark of **leading event management platforms**:
   - **Eventbrite** (Public discovery & consumer ticketing)
   - **Cvent** (Enterprise corporate conferences & venue RFPs)
   - **Whova** (Academic & collegiate events, mobile networking)
   - **Planning Pod** (All-in-one suite for private and wedding coordinators)
   - **RSVPify** (Private guest list gatekeeping & seating arrangements)
   - **PartySlate** (Visual photo portfolio and luxury vendor directory)
3. Providing interactive utilities:
   - Dynamic **Budget Calculator** with real-time per-attendee cost recalculations
   - Interactive **Milestone Checklist** with stage-wise progress tracking
   - Algorithmic **Decision Support Advisor Quiz** to calculate optimal platform stack
   - Digital **Attendee RSVP & Barcode Pass Generation** with QR code simulation
   - Client-side event creation and hosting with `localStorage` persistence

---

## 🚀 How to Run the Project

This web application is built using standard, dependency-free web technologies: **Pure Semantic HTML5, Modern CSS3 with CSS Variables & Dark Mode, and ES6 JavaScript**.

### Option 1: Live Local Server (Currently Running)
The project is hosted and active locally on port `8080`:
```bash
python3 -m http.server 8080
```
Open your browser and navigate to:
```
http://localhost:8080/
```

### Option 2: Direct File Opening
Double click `index.html` or open it in any modern browser (Chrome, Edge, Safari, Firefox). No internet or external build tools (`npm`, `webpack`) are strictly required.

---

## 📂 Project Directory Structure

```
24BDA70266_Kavya_24BDS-4NTPP:A/
├── index.html            # Main Single-Page Application (SPA) layout & all view sections
├── README.md             # Project documentation, college experiment dossier & lab guide
├── css/
│   └── style.css         # Modern design system, HSL color tokens, dark/light theme, print CSS
└── js/
    ├── data.js           # Datasets: 7 event categories, seeded events, 6 platform specifications
    └── app.js            # Core application state, SPA routing, budget math, modal controllers
```

---

## 🔬 Key Features for College Evaluation

1. **Homepage:**
   - Website brand logo & academic credentials badge
   - Hero section with live search and quick-filter category pills
   - Featured event planners/platforms grid
   - 4-step event planning roadmap
   - Interactive Dark/Light mode switcher with persistence

2. **Events Discovery Catalog:**
   - 7 distinct categories with real-time category filtering pills
   - Instant search by title, location, city, and organizer
   - Sort by upcoming date, popularity/attendees, or price (Low/High)
   - Detailed modal with event agenda timeline, highlights, and venue details
   - Instant registration with custom ticket quantity and dynamic badge issuance

3. **Platform Comparison & Benchmarking (Academic Core):**
   - Side-by-side comparative selector (compare any 3 platforms across 8 dimensions)
   - Interactive 3-question Platform Recommendation Advisor Quiz
   - Full master feature matrix table across all 6 evaluated platforms
   - Academic synthesis and findings report

4. **Planner & Budget Calculator:**
   - Real-time sliders for 7 cost centers: Venue, Catering, Decor, AV, Marketing, Staffing, Contingency
   - Live dynamic calculation of total budget, per-attendee expense, and percentage allocation
   - Milestone checklist with progress bar and custom task creation
   - One-click print/export plan

5. **My Passes / Attendee Portal:**
   - Access saved tickets and registrations
   - Digital booking reference codes and simulated QR/barcode passes
   - Direct print admission pass function

6. **Academic Experiment Dossier / Viva Guide:**
   - Dedicated modal accessible from nav bar or hero banner
   - Complete experiment writeup: Aim, Theory, Comparison Matrix, Architecture
   - Step-by-step viva presentation walkthrough
   - 5 frequently asked viva questions with model answers
   - Printable university lab report format

---

## 🎓 Viva Voce Quick Revision Notes

- **Q1: What are the two dominant business models in event platforms?**  
  *Answer:* Commission per ticket (e.g. Eventbrite 3.7% + fee) vs Fixed SaaS subscription (e.g. Planning Pod monthly fee).
- **Q2: Why is Whova preferred for college fests?**  
  *Answer:* It emphasizes attendee networking, gamified leaderboards, multi-track agendas, and student interaction.
- **Q3: How does the dynamic budget allocation operate?**  
  *Answer:* `Cost Per Attendee = Total Planned Budget / Expected Headcount`. Each allocation category updates in real time using slider DOM input events.
- **Q4: How is state persisted without an external database?**  
  *Answer:* Through HTML5 `window.localStorage` serializing JSON structures for newly created events and ticket registrations.
