/**
 * OmniEvent - Event Planning & Platform Analyzer
 * Core Application Logic & State Management
 */

// Application State
const state = {
  currentView: 'home',
  events: [],
  categories: [],
  platforms: [],
  selectedCategory: 'all',
  searchQuery: '',
  sortBy: 'date-asc',
  selectedPlatforms: ['eventbrite', 'cvent', 'whova'],
  activeModalEvent: null,
  rsvps: [],
  checklist: [],
  budget: {
    eventName: 'Annual Tech & Cultural Gala 2026',
    eventType: 'college',
    guests: 350,
    totalBudget: 15000,
    allocations: {
      venue: 30,
      catering: 30,
      decor: 15,
      avProduction: 10,
      marketing: 5,
      staffing: 5,
      contingency: 5
    }
  }
};

// Initialize Application
document.addEventListener('DOMContentLoaded', () => {
  initData();
  initTheme();
  initNavigation();
  initHomeView();
  initEventsView();
  initComparisonView();
  initPlannerView();
  initRSVPsView();
  initModals();
});

/* ==========================================================================
   INITIALIZATION & DATA LOADING
   ========================================================================== */
function initData() {
  // Load custom events from localStorage if any, or seed with APP_DATA
  const storedEvents = localStorage.getItem('omnievent_custom_events');
  if (storedEvents) {
    try {
      const parsed = JSON.parse(storedEvents);
      state.events = [...APP_DATA.events, ...parsed];
    } catch (e) {
      state.events = [...APP_DATA.events];
    }
  } else {
    state.events = [...APP_DATA.events];
  }

  state.categories = APP_DATA.categories;
  state.platforms = APP_DATA.platforms;

  // Load RSVPs
  const storedRSVPs = localStorage.getItem('omnievent_rsvps');
  if (storedRSVPs) {
    try {
      state.rsvps = JSON.parse(storedRSVPs);
    } catch (e) {
      state.rsvps = [];
    }
  }

  // Load Checklist
  const storedChecklist = localStorage.getItem('omnievent_checklist');
  if (storedChecklist) {
    try {
      state.checklist = JSON.parse(storedChecklist);
    } catch (e) {
      state.checklist = [...APP_DATA.defaultChecklist];
    }
  } else {
    state.checklist = [...APP_DATA.defaultChecklist];
  }

  // Load Planner Budget
  const storedBudget = localStorage.getItem('omnievent_budget');
  if (storedBudget) {
    try {
      state.budget = JSON.parse(storedBudget);
    } catch (e) {
      // keep default
    }
  }

  updateRSVPBadge();
}

function initTheme() {
  const savedTheme = localStorage.getItem('omnievent_theme') || 'light';
  document.documentElement.setAttribute('data-theme', savedTheme);
  updateThemeIcon(savedTheme);

  const themeBtn = document.getElementById('theme-toggle-btn');
  if (themeBtn) {
    themeBtn.addEventListener('click', () => {
      const current = document.documentElement.getAttribute('data-theme') || 'light';
      const newTheme = current === 'dark' ? 'light' : 'dark';
      document.documentElement.setAttribute('data-theme', newTheme);
      localStorage.setItem('omnievent_theme', newTheme);
      updateThemeIcon(newTheme);
    });
  }
}

function updateThemeIcon(theme) {
  const icon = document.querySelector('#theme-toggle-btn i');
  if (icon) {
    icon.className = theme === 'dark' ? 'fa-solid fa-sun' : 'fa-solid fa-moon';
  }
}

/* ==========================================================================
   NAVIGATION & VIEW ROUTING
   ========================================================================== */
function initNavigation() {
  const navLinks = document.querySelectorAll('[data-nav-target]');
  navLinks.forEach(link => {
    link.addEventListener('click', (e) => {
      e.preventDefault();
      const targetView = link.getAttribute('data-nav-target');
      switchView(targetView);
    });
  });

  // Mobile menu toggle
  const mobileToggle = document.getElementById('mobile-menu-toggle');
  const navMenu = document.querySelector('.nav-menu');
  if (mobileToggle && navMenu) {
    mobileToggle.addEventListener('click', () => {
      navMenu.classList.toggle('open-mobile');
    });
  }
}

function switchView(viewName) {
  state.currentView = viewName;

  // Toggle active view container
  document.querySelectorAll('.view-section').forEach(sec => {
    sec.classList.remove('active-view');
  });

  const activeSec = document.getElementById(`view-${viewName}`);
  if (activeSec) {
    activeSec.classList.add('active-view');
  }

  // Update active states on nav links
  document.querySelectorAll('.nav-link').forEach(link => {
    if (link.getAttribute('data-nav-target') === viewName) {
      link.classList.add('active');
    } else {
      link.classList.remove('active');
    }
  });

  // Scroll to top
  window.scrollTo({ top: 0, behavior: 'smooth' });

  // Refresh view specific state
  if (viewName === 'events') {
    renderEvents();
  } else if (viewName === 'comparison') {
    renderSideBySideComparison();
    renderComparisonTable();
  } else if (viewName === 'planner') {
    renderBudgetCalculator();
    renderChecklist();
  } else if (viewName === 'rsvps') {
    renderRSVPList();
  }
}

/* ==========================================================================
   HOME VIEW
   ========================================================================== */
function initHomeView() {
  // Render Category Cards
  const catGrid = document.getElementById('home-category-grid');
  if (catGrid) {
    const catsToShow = state.categories.filter(c => c.id !== 'all');
    catGrid.innerHTML = catsToShow.map(c => `
      <div class="category-card" onclick="filterByCategoryAndNavigate('${c.id}')">
        <div class="category-icon">
          <i class="fa-solid ${c.icon}"></i>
        </div>
        <h3 class="category-title">${c.name}</h3>
        <p class="category-count">${getEventCountByCategory(c.id)} Active Events</p>
      </div>
    `).join('');
  }

  // Render Platform Spotlight Cards on Home
  const platformsGrid = document.getElementById('home-platforms-grid');
  if (platformsGrid) {
    platformsGrid.innerHTML = state.platforms.slice(0, 3).map(p => `
      <div class="platform-card">
        <div>
          <div class="platform-header">
            <div class="platform-identity">
              <div class="platform-logo-icon" style="background-color: ${p.brandColor}">
                <i class="fa-solid ${p.logoIcon}"></i>
              </div>
              <div>
                <h4 class="platform-name">${p.name}</h4>
                <span class="badge badge-purple">${p.freeTierAvailable ? 'Free Tier Available' : 'Paid Tier'}</span>
              </div>
            </div>
            <div class="platform-score">
              <i class="fa-solid fa-star"></i> ${p.rating}/10
            </div>
          </div>
          <p class="platform-tagline">${p.tagline}</p>
          <div class="platform-badges">
            ${p.bestFor.map(b => `<span class="platform-badge-tag">${b}</span>`).join('')}
          </div>
          <div class="platform-specs">
            <div class="platform-spec-row">
              <span class="platform-spec-label">Pricing:</span>
              <span class="platform-spec-val">${p.pricingModel}</span>
            </div>
            <div class="platform-spec-row">
              <span class="platform-spec-label">Ticketing:</span>
              <span class="platform-spec-val">${p.features.ticketing.split(' - ')[0]}</span>
            </div>
            <div class="platform-spec-row">
              <span class="platform-spec-label">Ease of Use:</span>
              <span class="platform-spec-val">${p.easeOfUse} / 5.0</span>
            </div>
          </div>
        </div>
        <button class="btn btn-secondary btn-sm" onclick="compareSpecificPlatform('${p.id}')">
          <i class="fa-solid fa-chart-simple"></i> View Experiment Analysis
        </button>
      </div>
    `).join('');
  }

  // Hero Search Form Handler
  const heroSearchBtn = document.getElementById('hero-search-btn');
  if (heroSearchBtn) {
    heroSearchBtn.addEventListener('click', () => {
      const keyword = document.getElementById('hero-keyword-input')?.value || '';
      const category = document.getElementById('hero-category-select')?.value || 'all';

      state.searchQuery = keyword;
      state.selectedCategory = category;

      switchView('events');

      const eventSearchInput = document.getElementById('event-search-input');
      if (eventSearchInput) eventSearchInput.value = keyword;

      highlightActiveCategoryPill(category);
    });
  }
}

function getEventCountByCategory(categoryId) {
  if (categoryId === 'all') return state.events.length;
  return state.events.filter(e => e.category === categoryId).length;
}

window.filterByCategoryAndNavigate = function(categoryId) {
  state.selectedCategory = categoryId;
  state.searchQuery = '';
  switchView('events');
  highlightActiveCategoryPill(categoryId);
};

window.compareSpecificPlatform = function(platformId) {
  state.selectedPlatforms[0] = platformId;
  switchView('comparison');
};

/* ==========================================================================
   EVENTS VIEW
   ========================================================================== */
function initEventsView() {
  // Category Pills
  const pillsContainer = document.getElementById('category-pills-container');
  if (pillsContainer) {
    pillsContainer.innerHTML = state.categories.map(c => `
      <button class="cat-pill ${c.id === state.selectedCategory ? 'active' : ''}" data-category-id="${c.id}" onclick="onCategoryPillClick('${c.id}')">
        <i class="fa-solid ${c.icon}"></i> ${c.name}
      </button>
    `).join('');
  }

  // Live Search Input
  const searchInput = document.getElementById('event-search-input');
  if (searchInput) {
    searchInput.addEventListener('input', (e) => {
      state.searchQuery = e.target.value.trim().toLowerCase();
      renderEvents();
    });
  }

  // Sort Select
  const sortSelect = document.getElementById('event-sort-select');
  if (sortSelect) {
    sortSelect.addEventListener('change', (e) => {
      state.sortBy = e.target.value;
      renderEvents();
    });
  }

  renderEvents();
}

window.onCategoryPillClick = function(categoryId) {
  state.selectedCategory = categoryId;
  highlightActiveCategoryPill(categoryId);
  renderEvents();
};

function highlightActiveCategoryPill(categoryId) {
  document.querySelectorAll('.cat-pill').forEach(pill => {
    if (pill.getAttribute('data-category-id') === categoryId) {
      pill.classList.add('active');
    } else {
      pill.classList.remove('active');
    }
  });
}

function renderEvents() {
  const grid = document.getElementById('events-catalog-grid');
  const countBadge = document.getElementById('events-count-display');
  if (!grid) return;

  // Filter
  let filtered = state.events.filter(evt => {
    const matchesCat = state.selectedCategory === 'all' || evt.category === state.selectedCategory;
    const matchesSearch = !state.searchQuery ||
      evt.title.toLowerCase().includes(state.searchQuery) ||
      evt.description.toLowerCase().includes(state.searchQuery) ||
      evt.city.toLowerCase().includes(state.searchQuery) ||
      evt.organizer.toLowerCase().includes(state.searchQuery);
    return matchesCat && matchesSearch;
  });

  // Sort
  if (state.sortBy === 'date-asc') {
    filtered.sort((a, b) => new Date(a.date) - new Date(b.date));
  } else if (state.sortBy === 'price-low') {
    filtered.sort((a, b) => a.price - b.price);
  } else if (state.sortBy === 'price-high') {
    filtered.sort((a, b) => b.price - a.price);
  } else if (state.sortBy === 'popularity') {
    filtered.sort((a, b) => b.attendees - a.attendees);
  }

  if (countBadge) {
    countBadge.textContent = `Showing ${filtered.length} of ${state.events.length} events`;
  }

  if (filtered.length === 0) {
    grid.innerHTML = `
      <div style="grid-column: 1 / -1; text-align: center; padding: 4rem 1rem;">
        <i class="fa-regular fa-calendar-xmark" style="font-size: 3rem; color: var(--text-light); margin-bottom: 1rem;"></i>
        <h3>No Events Found</h3>
        <p style="color: var(--text-muted); margin-bottom: 1.5rem;">Try changing your search keywords or category filters.</p>
        <button class="btn btn-primary btn-sm" onclick="resetFilters()">Reset All Filters</button>
      </div>
    `;
    return;
  }

  grid.innerHTML = filtered.map(evt => {
    const formattedDate = new Date(evt.date).toLocaleDateString('en-US', {
      month: 'short',
      day: 'numeric',
      year: 'numeric'
    });

    const isFull = evt.attendees >= evt.maxCapacity;

    return `
      <div class="event-card" id="card-${evt.id}">
        <div class="event-card-media">
          <img src="${evt.image}" alt="${evt.title}" loading="lazy" />
          <div class="event-badge-overlay">
            <span class="badge ${evt.badgeColor || 'badge-purple'}">${evt.badge || evt.categoryLabel}</span>
          </div>
          <div class="event-price-overlay">
            ${evt.price === 0 ? 'FREE' : '$' + evt.price}
          </div>
        </div>

        <div class="event-card-body">
          <div class="event-meta-info">
            <span><i class="fa-regular fa-calendar"></i> ${formattedDate}</span>
            <span>•</span>
            <span><i class="fa-regular fa-clock"></i> ${evt.time.split(' - ')[0]}</span>
          </div>

          <h3 class="event-card-title">${evt.title}</h3>
          <p class="event-card-desc">${evt.description}</p>

          <ul class="event-details-list">
            <li><i class="fa-solid fa-location-dot"></i> ${evt.location}</li>
            <li><i class="fa-solid fa-user-tie"></i> Organised by ${evt.organizer}</li>
          </ul>

          <div class="event-card-footer">
            <div class="attendees-meter">
              <i class="fa-solid fa-users"></i> <span>${evt.attendees}</span> / ${evt.maxCapacity} registered
            </div>
            <div style="display: flex; gap: 0.5rem;">
              <button class="btn btn-secondary btn-sm" onclick="openEventDetailsModal('${evt.id}')">
                Details
              </button>
              <button class="btn btn-primary btn-sm" onclick="openRSVPModal('${evt.id}')" ${isFull ? 'disabled' : ''}>
                ${isFull ? 'Sold Out' : (evt.price === 0 ? 'Free RSVP' : 'Book Ticket')}
              </button>
            </div>
          </div>
        </div>
      </div>
    `;
  }).join('');
}

window.resetFilters = function() {
  state.selectedCategory = 'all';
  state.searchQuery = '';
  const searchInput = document.getElementById('event-search-input');
  if (searchInput) searchInput.value = '';
  highlightActiveCategoryPill('all');
  renderEvents();
};

/* ==========================================================================
   PLATFORM COMPARISON & EXPERIMENT VIEW
   ========================================================================== */
function initComparisonView() {
  const p1Select = document.getElementById('platform-select-1');
  const p2Select = document.getElementById('platform-select-2');
  const p3Select = document.getElementById('platform-select-3');

  if (p1Select && p2Select && p3Select) {
    const renderOptions = (selectedId) => {
      return state.platforms.map(p => `
        <option value="${p.id}" ${p.id === selectedId ? 'selected' : ''}>${p.name} (${p.rating}/10)</option>
      `).join('');
    };

    p1Select.innerHTML = renderOptions(state.selectedPlatforms[0]);
    p2Select.innerHTML = renderOptions(state.selectedPlatforms[1]);
    p3Select.innerHTML = renderOptions(state.selectedPlatforms[2]);

    p1Select.addEventListener('change', (e) => {
      state.selectedPlatforms[0] = e.target.value;
      renderSideBySideComparison();
    });
    p2Select.addEventListener('change', (e) => {
      state.selectedPlatforms[1] = e.target.value;
      renderSideBySideComparison();
    });
    p3Select.addEventListener('change', (e) => {
      state.selectedPlatforms[2] = e.target.value;
      renderSideBySideComparison();
    });
  }

  // Advisor Quiz Form
  const quizForm = document.getElementById('platform-advisor-form');
  if (quizForm) {
    quizForm.addEventListener('submit', (e) => {
      e.preventDefault();
      calculatePlatformRecommendation();
    });
  }

  renderSideBySideComparison();
  renderComparisonTable();
}

function renderSideBySideComparison() {
  const container = document.getElementById('side-by-side-comparison-cards');
  if (!container) return;

  const platforms = state.selectedPlatforms.map(id => state.platforms.find(p => p.id === id)).filter(Boolean);

  container.innerHTML = platforms.map((p, idx) => `
    <div class="compare-col-card ${idx === 0 ? 'highlighted' : ''}">
      <div class="compare-header">
        <div class="compare-logo" style="background-color: ${p.brandColor}">
          <i class="fa-solid ${p.logoIcon}"></i>
        </div>
        <h3 class="compare-title">${p.name}</h3>
        <p class="compare-tagline">${p.tagline}</p>
        <div style="margin-top: 0.75rem;">
          <span class="badge badge-emerald"><i class="fa-solid fa-star"></i> Score: ${p.rating} / 10</span>
        </div>
      </div>

      <div class="compare-features-list">
        <div class="compare-feature-item">
          <span class="c-feat-label">Best Suited For</span>
          <span class="c-feat-val">${p.bestFor.join(', ')}</span>
        </div>

        <div class="compare-feature-item">
          <span class="c-feat-label">Pricing Architecture</span>
          <span class="c-feat-val">${p.pricingModel}</span>
        </div>

        <div class="compare-feature-item">
          <span class="c-feat-label">Ticketing & Registration</span>
          <span class="c-feat-val">${p.features.ticketing}</span>
        </div>

        <div class="compare-feature-item">
          <span class="c-feat-label">Floor Planning & Seating</span>
          <span class="c-feat-val">${p.features.floorPlanning}</span>
        </div>

        <div class="compare-feature-item">
          <span class="c-feat-label">Mobile App & Networking</span>
          <span class="c-feat-val">${p.features.networkingApp}</span>
        </div>

        <div class="compare-feature-item">
          <span class="c-feat-label">Budget & Procurement</span>
          <span class="c-feat-val">${p.features.budgetTracking}</span>
        </div>

        <div class="compare-feature-item">
          <span class="c-feat-label">Vendor Management</span>
          <span class="c-feat-val">${p.features.vendorManagement}</span>
        </div>
      </div>

      <div class="compare-pros-cons">
        <h5 style="font-size: 0.85rem; margin-bottom: 0.5rem;"><i class="fa-solid fa-thumbs-up" style="color: var(--success)"></i> Strengths</h5>
        <ul class="pros-list" style="margin-bottom: 1rem;">
          ${p.experimentAnalysis.pros.map(pr => `<li>✓ ${pr}</li>`).join('')}
        </ul>

        <h5 style="font-size: 0.85rem; margin-bottom: 0.5rem;"><i class="fa-solid fa-triangle-exclamation" style="color: var(--danger)"></i> Limitations</h5>
        <ul class="cons-list">
          ${p.experimentAnalysis.cons.map(cn => `<li>✕ ${cn}</li>`).join('')}
        </ul>
      </div>

      <div style="margin-top: 1.5rem; padding-top: 1rem; border-top: 1px solid var(--border-color); font-size: 0.85rem; color: var(--text-muted);">
        <strong>Academic Verdict:</strong> ${p.experimentAnalysis.idealVerdict}
      </div>
    </div>
  `).join('');
}

function renderComparisonTable() {
  const tbody = document.getElementById('matrix-table-body');
  if (!tbody) return;

  const featuresToDisplay = [
    { label: 'Category Focus', key: 'bestFor', format: (val) => val.slice(0, 2).join(', ') },
    { label: 'Pricing Model', key: 'pricingModel' },
    { label: 'Free Tier Available', key: 'freeTierAvailable', format: (val) => val ? '✅ Yes' : '❌ No' },
    { label: 'Ticketing & RSVP', key: (p) => p.features.ticketing.split(' - ')[0] },
    { label: 'Seating / Floor Maps', key: (p) => p.features.floorPlanning.split(' - ')[0] },
    { label: 'Mobile App / Chat', key: (p) => p.features.networkingApp.split(' - ')[0] },
    { label: 'Budget Tracker', key: (p) => p.features.budgetTracking.split(' - ')[0] },
    { label: 'Vendor Contracts', key: (p) => p.features.vendorManagement.split(' - ')[0] },
    { label: 'Ease of Use (5)', key: 'easeOfUse', format: (val) => `${val} ★` },
    { label: 'Scalability (5)', key: 'scalability', format: (val) => `${val} ★` },
    { label: 'Overall Rating (10)', key: 'rating', format: (val) => `<strong>${val} / 10</strong>` }
  ];

  tbody.innerHTML = featuresToDisplay.map(f => {
    const cells = state.platforms.map(p => {
      let content = '';
      if (typeof f.key === 'function') {
        content = f.key(p);
      } else {
        const raw = p[f.key];
        content = f.format ? f.format(raw) : raw;
      }
      return `<td>${content}</td>`;
    }).join('');

    return `
      <tr>
        <td>${f.label}</td>
        ${cells}
      </tr>
    `;
  }).join('');
}

function calculatePlatformRecommendation() {
  const typeVal = document.querySelector('input[name="quiz-type"]:checked')?.value || 'college';
  const scaleVal = document.querySelector('input[name="quiz-scale"]:checked')?.value || 'medium';
  const priorityVal = document.querySelector('input[name="quiz-priority"]:checked')?.value || 'cost';

  // Compute scores
  const scores = {};
  state.platforms.forEach(p => scores[p.id] = 0);

  // Match weights from APP_DATA.quizCriteria
  APP_DATA.quizCriteria.forEach(criterion => {
    let chosenVal = typeVal;
    if (criterion.id === 'scale') chosenVal = scaleVal;
    if (criterion.id === 'priority') chosenVal = priorityVal;

    const opt = criterion.options.find(o => o.value === chosenVal);
    if (opt && opt.weight) {
      Object.entries(opt.weight).forEach(([pId, w]) => {
        if (scores[pId] !== undefined) scores[pId] += w;
      });
    }
  });

  // Find highest scoring platform
  let topPlatformId = 'eventbrite';
  let maxScore = -1;
  Object.entries(scores).forEach(([id, s]) => {
    if (s > maxScore) {
      maxScore = s;
      topPlatformId = id;
    }
  });

  const bestPlatform = state.platforms.find(p => p.id === topPlatformId);
  const resultArea = document.getElementById('quiz-result-area');
  if (resultArea && bestPlatform) {
    resultArea.style.display = 'block';
    resultArea.innerHTML = `
      <div style="display: flex; align-items: center; justify-content: space-between; flex-wrap: wrap; gap: 1rem; margin-bottom: 1rem;">
        <div style="display: flex; align-items: center; gap: 0.85rem;">
          <div class="platform-logo-icon" style="background-color: ${bestPlatform.brandColor}">
            <i class="fa-solid ${bestPlatform.logoIcon}"></i>
          </div>
          <div>
            <h4 style="font-size: 1.35rem; font-weight: 800;">Recommended: ${bestPlatform.name}</h4>
            <p style="font-size: 0.9rem; color: var(--text-muted);">${bestPlatform.tagline}</p>
          </div>
        </div>
        <span class="badge badge-emerald" style="font-size: 0.9rem; padding: 0.4rem 0.85rem;">
          Match Score: ${Math.round((maxScore / 16) * 100)}% Match
        </span>
      </div>
      <p style="font-size: 0.95rem; line-height: 1.6; margin-bottom: 1.25rem;">
        <strong>Why this fits your experiment parameters:</strong> For a <em>${typeVal}</em> event of <em>${scaleVal}</em> scale prioritizing <em>${priorityVal}</em>, 
        <strong>${bestPlatform.name}</strong> provides the optimal balance of features without unnecessary architectural overhead.
      </p>
      <div style="display: flex; gap: 0.75rem; flex-wrap: wrap;">
        <button class="btn btn-primary btn-sm" onclick="compareSpecificPlatform('${bestPlatform.id}')">
          <i class="fa-solid fa-code-compare"></i> Compare Against Others
        </button>
        <button class="btn btn-secondary btn-sm" onclick="switchView('planner')">
          <i class="fa-solid fa-calculator"></i> Open Budget & Milestone Planner
        </button>
      </div>
    `;
    resultArea.scrollIntoView({ behavior: 'smooth', block: 'nearest' });
  }
}

/* ==========================================================================
   EVENT PLANNER & BUDGET CALCULATOR
   ========================================================================== */
function initPlannerView() {
  const totalBudgetInput = document.getElementById('plan-total-budget');
  const guestsInput = document.getElementById('plan-guest-count');
  const eventNameInput = document.getElementById('plan-event-name');
  const eventTypeSelect = document.getElementById('plan-event-type');

  if (totalBudgetInput) totalBudgetInput.value = state.budget.totalBudget;
  if (guestsInput) guestsInput.value = state.budget.guests;
  if (eventNameInput) eventNameInput.value = state.budget.eventName;
  if (eventTypeSelect) eventTypeSelect.value = state.budget.eventType;

  // Listeners for core inputs
  const inputs = [totalBudgetInput, guestsInput, eventNameInput, eventTypeSelect];
  inputs.forEach(inp => {
    if (inp) {
      inp.addEventListener('input', () => {
        state.budget.totalBudget = Math.max(100, Number(totalBudgetInput.value) || 0);
        state.budget.guests = Math.max(1, Number(guestsInput.value) || 1);
        state.budget.eventName = eventNameInput.value;
        state.budget.eventType = eventTypeSelect.value;
        saveBudgetState();
        renderBudgetCalculator();
      });
    }
  });

  // Slider inputs
  document.querySelectorAll('.budget-allocation-slider').forEach(slider => {
    slider.addEventListener('input', (e) => {
      const key = e.target.getAttribute('data-budget-key');
      const val = Number(e.target.value);
      state.budget.allocations[key] = val;
      saveBudgetState();
      renderBudgetCalculator();
    });
  });

  // Add Task Input Form
  const addTaskBtn = document.getElementById('add-task-btn');
  const taskTextInput = document.getElementById('new-task-text');
  const taskStageSelect = document.getElementById('new-task-stage');

  if (addTaskBtn && taskTextInput) {
    addTaskBtn.addEventListener('click', () => {
      const text = taskTextInput.value.trim();
      const stage = taskStageSelect ? taskStageSelect.value : '1 Month Before';
      if (!text) return;

      const newTask = {
        id: 'chk-' + Date.now(),
        stage: stage,
        text: text,
        done: false
      };

      state.checklist.push(newTask);
      localStorage.setItem('omnievent_checklist', JSON.stringify(state.checklist));
      taskTextInput.value = '';
      renderChecklist();
    });
  }

  // Print / Export Plan
  const exportBtn = document.getElementById('export-plan-btn');
  if (exportBtn) {
    exportBtn.addEventListener('click', () => {
      window.print();
    });
  }

  renderBudgetCalculator();
  renderChecklist();
}

function saveBudgetState() {
  localStorage.setItem('omnievent_budget', JSON.stringify(state.budget));
}

function renderBudgetCalculator() {
  const total = state.budget.totalBudget;
  const guests = state.budget.guests;
  const allocs = state.budget.allocations;

  // Calculate total percentage
  const totalPercent = Object.values(allocs).reduce((a, b) => a + b, 0);

  // Update slider displays and calculated dollars
  Object.entries(allocs).forEach(([key, pct]) => {
    const valSpan = document.getElementById(`budget-val-${key}`);
    const pctSpan = document.getElementById(`budget-pct-${key}`);
    const slider = document.querySelector(`.budget-allocation-slider[data-budget-key="${key}"]`);

    const dollars = Math.round((pct / 100) * total);
    if (valSpan) valSpan.textContent = `$${dollars.toLocaleString()}`;
    if (pctSpan) pctSpan.textContent = `${pct}%`;
    if (slider) slider.value = pct;
  });

  // Summary Banner Displays
  const costPerGuest = Math.round(total / guests);
  const dispTotal = document.getElementById('disp-total-budget');
  const dispPerGuest = document.getElementById('disp-cost-per-guest');
  const dispPercent = document.getElementById('disp-alloc-percent');

  if (dispTotal) dispTotal.textContent = `$${total.toLocaleString()}`;
  if (dispPerGuest) dispPerGuest.textContent = `$${costPerGuest.toLocaleString()}`;
  if (dispPercent) {
    dispPercent.textContent = `${totalPercent}%`;
    dispPercent.style.color = totalPercent === 100 ? 'var(--success)' : (totalPercent > 100 ? 'var(--danger)' : 'var(--accent)');
  }
}

function renderChecklist() {
  const container = document.getElementById('checklist-items-container');
  const fill = document.getElementById('checklist-progress-fill');
  const percentText = document.getElementById('checklist-percent-text');
  if (!container) return;

  const total = state.checklist.length;
  const doneCount = state.checklist.filter(c => c.done).length;
  const pct = total === 0 ? 0 : Math.round((doneCount / total) * 100);

  if (fill) fill.style.width = `${pct}%`;
  if (percentText) percentText.textContent = `${pct}% Completed (${doneCount}/${total} tasks)`;

  container.innerHTML = state.checklist.map(item => `
    <div class="checklist-item ${item.done ? 'done' : ''}" onclick="toggleChecklistItem('${item.id}')">
      <input type="checkbox" ${item.done ? 'checked' : ''} onclick="event.stopPropagation(); toggleChecklistItem('${item.id}')" />
      <span class="checklist-text">${item.text}</span>
      <span class="checklist-stage-badge">${item.stage}</span>
      <button class="btn-icon" style="width: 24px; height: 24px; color: var(--text-light);" onclick="event.stopPropagation(); deleteChecklistItem('${item.id}')" title="Delete Task">
        <i class="fa-solid fa-xmark"></i>
      </button>
    </div>
  `).join('');
}

window.toggleChecklistItem = function(id) {
  const item = state.checklist.find(c => c.id === id);
  if (item) {
    item.done = !item.done;
    localStorage.setItem('omnievent_checklist', JSON.stringify(state.checklist));
    renderChecklist();
  }
};

window.deleteChecklistItem = function(id) {
  state.checklist = state.checklist.filter(c => c.id !== id);
  localStorage.setItem('omnievent_checklist', JSON.stringify(state.checklist));
  renderChecklist();
};

/* ==========================================================================
   MY RSVPS / SAVED EVENTS
   ========================================================================== */
function initRSVPsView() {
  renderRSVPList();
}

function updateRSVPBadge() {
  const badge = document.getElementById('nav-rsvps-count');
  if (badge) {
    badge.textContent = state.rsvps.length;
    badge.style.display = state.rsvps.length > 0 ? 'inline-flex' : 'none';
  }
}

function renderRSVPList() {
  const container = document.getElementById('rsvps-tickets-container');
  const emptyState = document.getElementById('rsvps-empty-state');
  if (!container) return;

  if (state.rsvps.length === 0) {
    if (emptyState) emptyState.style.display = 'block';
    container.innerHTML = '';
    return;
  }

  if (emptyState) emptyState.style.display = 'none';

  container.innerHTML = state.rsvps.map(rsvp => {
    const event = state.events.find(e => e.id === rsvp.eventId) || {
      title: rsvp.eventTitle,
      date: rsvp.eventDate,
      location: rsvp.eventLocation,
      image: 'https://images.unsplash.com/photo-1523580494863-6f3031224c94?auto=format&fit=crop&w=800&q=80'
    };

    return `
      <div class="ticket-pass-card">
        <div class="ticket-qr-box">
          <i class="fa-solid fa-qrcode"></i>
          <span style="font-size: 0.65rem; font-weight: 700; margin-top: 0.35rem;">SCAN PASS</span>
        </div>
        <div class="ticket-info">
          <div style="display: flex; justify-content: space-between; align-items: flex-start; margin-bottom: 0.5rem;">
            <div>
              <span class="badge badge-purple" style="margin-bottom: 0.35rem;">Confirmed Pass</span>
              <h3 style="font-size: 1.25rem; font-weight: 800;">${rsvp.eventTitle}</h3>
            </div>
            <span style="font-size: 0.8rem; font-family: monospace; font-weight: 700; color: var(--primary);">
              Ref: ${rsvp.bookingRef}
            </span>
          </div>

          <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(180px, 1fr)); gap: 0.5rem; font-size: 0.85rem; color: var(--text-muted); margin-bottom: 1rem;">
            <div><i class="fa-regular fa-calendar" style="color: var(--primary);"></i> ${new Date(rsvp.eventDate).toLocaleDateString()}</div>
            <div><i class="fa-solid fa-location-dot" style="color: var(--primary);"></i> ${rsvp.eventLocation}</div>
            <div><i class="fa-solid fa-user" style="color: var(--primary);"></i> Guest: <strong>${rsvp.userName}</strong></div>
            <div><i class="fa-solid fa-ticket" style="color: var(--primary);"></i> ${rsvp.ticketsCount} Ticket(s) ($${rsvp.totalPaid})</div>
          </div>

          <div style="display: flex; gap: 0.5rem; justify-content: flex-end;">
            <button class="btn btn-secondary btn-sm" onclick="printTicketPass('${rsvp.bookingRef}')">
              <i class="fa-solid fa-print"></i> Print Ticket
            </button>
            <button class="btn btn-outline btn-sm" style="color: var(--danger); border-color: var(--danger);" onclick="cancelRSVP('${rsvp.bookingRef}')">
              <i class="fa-solid fa-trash-can"></i> Cancel
            </button>
          </div>
        </div>
      </div>
    `;
  }).join('');
}

window.cancelRSVP = function(ref) {
  if (confirm(`Are you sure you want to cancel booking ${ref}?`)) {
    state.rsvps = state.rsvps.filter(r => r.bookingRef !== ref);
    localStorage.setItem('omnievent_rsvps', JSON.stringify(state.rsvps));
    updateRSVPBadge();
    renderRSVPList();
  }
};

window.printTicketPass = function(ref) {
  window.print();
};

/* ==========================================================================
   MODALS (DETAILS, RSVP, CREATE EVENT)
   ========================================================================== */
function initModals() {
  // Close buttons
  document.querySelectorAll('[data-modal-close]').forEach(btn => {
    btn.addEventListener('click', () => {
      closeAllModals();
    });
  });

  // Close on backdrop click
  document.querySelectorAll('.modal-backdrop').forEach(modal => {
    modal.addEventListener('click', (e) => {
      if (e.target === modal) {
        closeAllModals();
      }
    });
  });

  // RSVP Form Submission
  const rsvpForm = document.getElementById('rsvp-submission-form');
  if (rsvpForm) {
    rsvpForm.addEventListener('submit', (e) => {
      e.preventDefault();
      submitRSVPForm();
    });
  }

  // Create Event Form Submission
  const createEventForm = document.getElementById('create-event-form');
  if (createEventForm) {
    createEventForm.addEventListener('submit', (e) => {
      e.preventDefault();
      submitCreateEventForm();
    });
  }

  // Open Create Event Modal Button in Header & Catalog
  document.querySelectorAll('.open-create-event-btn').forEach(btn => {
    btn.addEventListener('click', () => {
      openCreateEventModal();
    });
  });

  // Open Experiment Report / Lab Manual Modal
  document.querySelectorAll('.open-experiment-report-btn').forEach(btn => {
    btn.addEventListener('click', (e) => {
      e.preventDefault();
      openExperimentReportModal();
    });
  });

  // Print Lab Dossier button
  const printDossierBtn = document.getElementById('print-lab-dossier-btn');
  if (printDossierBtn) {
    printDossierBtn.addEventListener('click', () => {
      printLabReport();
    });
  }
}

function openExperimentReportModal() {
  const modal = document.getElementById('experiment-report-modal');
  if (modal) {
    modal.classList.add('open');
  }
}

window.printLabReport = function() {
  document.body.classList.add('printing-report');
  window.print();
  setTimeout(() => {
    document.body.classList.remove('printing-report');
  }, 1000);
};

function closeAllModals() {
  document.querySelectorAll('.modal-backdrop').forEach(m => m.classList.remove('open'));
}

window.openEventDetailsModal = function(eventId) {
  const evt = state.events.find(e => e.id === eventId);
  if (!evt) return;

  state.activeModalEvent = evt;
  const modal = document.getElementById('event-details-modal');
  if (!modal) return;

  const formattedDate = new Date(evt.date).toLocaleDateString('en-US', {
    weekday: 'long',
    month: 'long',
    day: 'numeric',
    year: 'numeric'
  });

  document.getElementById('modal-event-img').src = evt.image;
  document.getElementById('modal-event-badge').className = `badge ${evt.badgeColor || 'badge-purple'}`;
  document.getElementById('modal-event-badge').textContent = evt.badge || evt.categoryLabel;
  document.getElementById('modal-event-title').textContent = evt.title;
  document.getElementById('modal-event-date').textContent = formattedDate;
  document.getElementById('modal-event-time').textContent = evt.time;
  document.getElementById('modal-event-venue').textContent = `${evt.location}, ${evt.city}`;
  document.getElementById('modal-event-price').textContent = evt.price === 0 ? 'Free Entry' : `$${evt.price} / ticket`;
  document.getElementById('modal-event-organizer').textContent = evt.organizer;
  document.getElementById('modal-event-desc').textContent = evt.description;

  // Highlights
  const highlightsList = document.getElementById('modal-event-highlights');
  if (highlightsList && evt.highlights) {
    highlightsList.innerHTML = evt.highlights.map(h => `<li><i class="fa-solid fa-check" style="color: var(--success); margin-right: 0.5rem;"></i>${h}</li>`).join('');
  }

  // Agenda
  const agendaList = document.getElementById('modal-event-agenda');
  if (agendaList && evt.agenda) {
    agendaList.innerHTML = evt.agenda.map(a => `
      <div class="agenda-item">
        <span class="agenda-time">${a.time}</span>
        <span>${a.activity}</span>
      </div>
    `).join('');
  }

  // Action button in modal
  const rsvpBtn = document.getElementById('modal-event-rsvp-btn');
  if (rsvpBtn) {
    rsvpBtn.onclick = () => {
      closeAllModals();
      openRSVPModal(evt.id);
    };
  }

  modal.classList.add('open');
};

window.openRSVPModal = function(eventId) {
  const evt = state.events.find(e => e.id === eventId);
  if (!evt) return;

  state.activeModalEvent = evt;
  const modal = document.getElementById('rsvp-modal');
  if (!modal) return;

  document.getElementById('rsvp-target-event-title').textContent = evt.title;
  document.getElementById('rsvp-target-event-price').textContent = evt.price === 0 ? 'Free Registration' : `$${evt.price} per ticket`;

  const qtyInput = document.getElementById('rsvp-ticket-qty');
  if (qtyInput) qtyInput.value = 1;

  modal.classList.add('open');
};

function submitRSVPForm() {
  const evt = state.activeModalEvent;
  if (!evt) return;

  const name = document.getElementById('rsvp-user-name')?.value || 'Guest Attendee';
  const email = document.getElementById('rsvp-user-email')?.value || 'guest@example.com';
  const qty = Number(document.getElementById('rsvp-ticket-qty')?.value) || 1;
  const totalPaid = evt.price * qty;

  const bookingRef = 'TKT-' + Math.random().toString(36).substring(2, 8).toUpperCase();

  const newRSVP = {
    bookingRef: bookingRef,
    eventId: evt.id,
    eventTitle: evt.title,
    eventDate: evt.date,
    eventLocation: evt.location,
    userName: name,
    userEmail: email,
    ticketsCount: qty,
    totalPaid: totalPaid,
    bookedAt: new Date().toISOString()
  };

  // Add to state and persistence
  state.rsvps.unshift(newRSVP);
  localStorage.setItem('omnievent_rsvps', JSON.stringify(state.rsvps));

  // Increment event attendee count
  evt.attendees = Math.min(evt.maxCapacity, evt.attendees + qty);
  renderEvents();
  updateRSVPBadge();

  closeAllModals();

  // Show Confirmation Pass Modal
  openConfirmationPassModal(newRSVP);
}

function openConfirmationPassModal(rsvp) {
  const modal = document.getElementById('confirmation-modal');
  if (!modal) return;

  document.getElementById('conf-ref').textContent = rsvp.bookingRef;
  document.getElementById('conf-title').textContent = rsvp.eventTitle;
  document.getElementById('conf-name').textContent = rsvp.userName;
  document.getElementById('conf-qty').textContent = `${rsvp.ticketsCount} Ticket(s)`;
  document.getElementById('conf-date').textContent = new Date(rsvp.eventDate).toLocaleDateString();

  modal.classList.add('open');
}

function openCreateEventModal() {
  const modal = document.getElementById('create-event-modal');
  if (modal) {
    modal.classList.add('open');
  }
}

function submitCreateEventForm() {
  const title = document.getElementById('ce-title')?.value.trim();
  const category = document.getElementById('ce-category')?.value || 'college';
  const date = document.getElementById('ce-date')?.value;
  const time = document.getElementById('ce-time')?.value || '10:00 AM - 05:00 PM';
  const location = document.getElementById('ce-location')?.value.trim();
  const city = document.getElementById('ce-city')?.value.trim() || 'Campus';
  const price = Number(document.getElementById('ce-price')?.value) || 0;
  const capacity = Number(document.getElementById('ce-capacity')?.value) || 300;
  const organizer = document.getElementById('ce-organizer')?.value.trim() || 'Student Committee';
  const description = document.getElementById('ce-desc')?.value.trim();
  let image = document.getElementById('ce-image')?.value.trim();

  if (!title || !date || !location || !description) {
    alert('Please fill in all required fields.');
    return;
  }

  if (!image) {
    // Default image by category
    const defaultImages = {
      wedding: 'https://images.unsplash.com/photo-1519741497674-611481863552?auto=format&fit=crop&w=800&q=80',
      birthday: 'https://images.unsplash.com/photo-1492684223066-81342ee5ff30?auto=format&fit=crop&w=800&q=80',
      corporate: 'https://images.unsplash.com/photo-1511578314322-379afb476865?auto=format&fit=crop&w=800&q=80',
      college: 'https://images.unsplash.com/photo-1523580494863-6f3031224c94?auto=format&fit=crop&w=800&q=80',
      concert: 'https://images.unsplash.com/photo-1470225620780-dba8ba36b745?auto=format&fit=crop&w=800&q=80',
      conference: 'https://images.unsplash.com/photo-1540575467063-178a50c2df87?auto=format&fit=crop&w=800&q=80',
      private: 'https://images.unsplash.com/photo-1533174072545-7a4b6ad7a6c3?auto=format&fit=crop&w=800&q=80'
    };
    image = defaultImages[category] || defaultImages.college;
  }

  const catObj = state.categories.find(c => c.id === category) || { name: 'Custom Event' };

  const newEvent = {
    id: 'evt-custom-' + Date.now(),
    title: title,
    category: category,
    categoryLabel: catObj.name,
    date: date,
    time: time,
    location: location,
    city: city,
    price: price,
    priceLabel: price === 0 ? 'Free Entry' : `$${price} / ticket`,
    image: image,
    badge: 'User Created',
    badgeColor: 'badge-emerald',
    attendees: 1,
    maxCapacity: capacity,
    organizer: organizer,
    featured: false,
    description: description,
    highlights: [
      'Interactive student participation session',
      'Exclusive networking and learning experience',
      'Certificate of attendance provided'
    ],
    agenda: [
      { time: time.split(' - ')[0] || '10:00 AM', activity: 'Registration & Welcome' },
      { time: '01:00 PM', activity: 'Main Program & Keynote' },
      { time: time.split(' - ')[1] || '05:00 PM', activity: 'Concluding Remarks & Social' }
    ]
  };

  // Prepend to state
  state.events.unshift(newEvent);

  // Save custom events to localStorage
  const customEvents = state.events.filter(e => e.id.startsWith('evt-custom-'));
  localStorage.setItem('omnievent_custom_events', JSON.stringify(customEvents));

  // Close modal and switch to events view
  closeAllModals();
  switchView('events');
  renderEvents();
}
