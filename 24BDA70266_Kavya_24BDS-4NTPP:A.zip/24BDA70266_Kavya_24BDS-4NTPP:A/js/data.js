/**
 * Event Planning Platform - Data Store
 * Contains pre-populated data for events, platforms comparison, categories, and planner templates.
 */

const APP_DATA = {
  categories: [
    { id: 'all', name: 'All Events', icon: 'fa-sparkles', count: 8 },
    { id: 'wedding', name: 'Weddings', icon: 'fa-heart', count: 1 },
    { id: 'birthday', name: 'Birthday Parties', icon: 'fa-cake-candles', count: 1 },
    { id: 'corporate', name: 'Corporate Events', icon: 'fa-briefcase', count: 2 },
    { id: 'college', name: 'College Events', icon: 'fa-graduation-cap', count: 2 },
    { id: 'concert', name: 'Concerts & Music', icon: 'fa-guitar', count: 1 },
    { id: 'conference', name: 'Conferences', icon: 'fa-microphone', count: 1 },
    { id: 'private', name: 'Private Parties', icon: 'fa-champagne-glasses', count: 1 }
  ],

  events: [
    {
      id: 'evt-1',
      title: 'InnovateX 2026: Inter-College Hackathon & Tech Fest',
      category: 'college',
      categoryLabel: 'College Event',
      date: '2026-10-24',
      time: '09:00 AM - 08:00 PM',
      location: 'Grand Auditorium, Tech University Campus',
      city: 'Metro Tech Hub',
      price: 0,
      priceLabel: 'Free Entry (Student ID)',
      image: 'https://images.unsplash.com/photo-1523580494863-6f3031224c94?auto=format&fit=crop&w=800&q=80',
      badge: 'College Special',
      badgeColor: 'badge-purple',
      attendees: 450,
      maxCapacity: 600,
      organizer: 'Dept of Computer Science & Student Union',
      featured: true,
      description: 'The premier annual collegiate technical summit featuring a 24-hour sprint hackathon, esports showdown, project exhibitions, and guest lectures from industry pioneers.',
      highlights: [
        'Over $10,000 in prizes and mentorship awards',
        'Keynote addresses by AI architects and startup founders',
        'Complimentary food trucks, energy drinks, and merchandise kit',
        'Direct hiring and internship booth activations'
      ],
      agenda: [
        { time: '09:00 AM', activity: 'Registration & Welcome Breakfast' },
        { time: '10:30 AM', activity: 'Hackathon Theme Reveal & Hacking Begins' },
        { time: '02:00 PM', activity: 'Expert Mentorship Speed-Rounds' },
        { time: '06:00 PM', activity: 'Project Submissions & Live Pitch Demos' },
        { time: '07:30 PM', activity: 'Awards Ceremony & Networking Mixer' }
      ]
    },
    {
      id: 'evt-2',
      title: 'The Regal Botanical Wedding Showcase & Gala',
      category: 'wedding',
      categoryLabel: 'Weddings',
      date: '2026-11-14',
      time: '04:00 PM - 10:00 PM',
      location: 'Emerald Hills Estate & Conservatory',
      city: 'Highland Valley',
      price: 75,
      priceLabel: '$75 per couple',
      image: 'https://images.unsplash.com/photo-1519741497674-611481863552?auto=format&fit=crop&w=800&q=80',
      badge: 'Luxury Showcase',
      badgeColor: 'badge-rose',
      attendees: 180,
      maxCapacity: 250,
      organizer: 'Celestial Vows Wedding Planners & Flora Studio',
      featured: true,
      description: 'An immersive experience for couples and event planners looking to explore luxury floral designs, multi-tiered artisanal cakes, bridal runway trends, and royal banquet arrangements.',
      highlights: [
        'Curated 5-course gourmet tasting menu with wine pairings',
        'Live acoustic string quartet and DJ transition showcase',
        'VIP access to top 20 verified bridal couture and jewelry ateliers',
        'Complimentary consultation with certified wedding stylists'
      ],
      agenda: [
        { time: '04:00 PM', activity: 'Champagne Reception & Garden Walkthrough' },
        { time: '05:30 PM', activity: 'Bridal & Groom Runway Fashion Presentation' },
        { time: '07:00 PM', activity: 'Artisanal Cake Tasting & Chef Table Showcase' },
        { time: '08:30 PM', activity: 'Evening Illumination & Fireworks Demo' }
      ]
    },
    {
      id: 'evt-3',
      title: 'Global Tech Leadership & AI Enterprise Summit',
      category: 'corporate',
      categoryLabel: 'Corporate Events',
      date: '2026-10-18',
      time: '08:30 AM - 06:00 PM',
      location: 'Metropolitan Convention & Expo Center, Hall A',
      city: 'Downtown Silicon District',
      price: 299,
      priceLabel: '$299 / delegate',
      image: 'https://images.unsplash.com/photo-1511578314322-379afb476865?auto=format&fit=crop&w=800&q=80',
      badge: 'Enterprise Summit',
      badgeColor: 'badge-blue',
      attendees: 920,
      maxCapacity: 1200,
      organizer: 'NextWave Corporate Events Group',
      featured: true,
      description: 'Connecting Fortune 500 executives, startup founders, venture capitalists, and technology researchers for 2 days of deep dive panels, executive roundtables, and enterprise networking.',
      highlights: [
        '30+ Keynotes from C-Suite leaders in AI, Cloud, and Cybersecurity',
        'Interactive VIP breakout lounges and B2B dealmaker suites',
        'Catered executive lunches, barista stations, and evening cocktail reception',
        'Full digital delegate dossier and recording access'
      ],
      agenda: [
        { time: '08:30 AM', activity: 'Executive Check-in & Breakfast Networking' },
        { time: '09:45 AM', activity: 'Opening Keynote: Autonomous AI in Modern Business' },
        { time: '12:30 PM', activity: 'Gourmet Networking Luncheon' },
        { time: '02:00 PM', activity: 'Breakout Sessions: FinTech, HealthTech & Supply Chain' },
        { time: '05:00 PM', activity: 'Venture Showcase & Sunset Rooftop Social' }
      ]
    },
    {
      id: 'evt-4',
      title: 'Neon Horizon: 21st Birthday Festival & Silent Disco',
      category: 'birthday',
      categoryLabel: 'Birthday Parties',
      date: '2026-10-31',
      time: '07:30 PM - 02:00 AM',
      location: 'The Warehouse Loft & Terrace',
      city: 'Arts District',
      price: 35,
      priceLabel: '$35 / ticket',
      image: 'https://images.unsplash.com/photo-1492684223066-81342ee5ff30?auto=format&fit=crop&w=800&q=80',
      badge: 'Nightlife',
      badgeColor: 'badge-amber',
      attendees: 195,
      maxCapacity: 250,
      organizer: 'VibeCraft Party Producers',
      featured: false,
      description: 'An electrifying neon-themed birthday bash featuring glow-in-the-dark face artists, 3-channel wireless silent disco, bespoke mocktail/cocktail bars, and retro arcade cabinets.',
      highlights: [
        '3 live DJs playing Synthwave, Afrobeat, and Chart-toppers',
        'Interactive 360-degree slow motion video photo booth',
        'Custom birthday balloon installations and LED backdrop',
        'Midnight gourmet sliders and churro dessert station'
      ],
      agenda: [
        { time: '07:30 PM', activity: 'Doors Open, Neon Face-Art & Welcome Cocktails' },
        { time: '09:00 PM', activity: '3-Channel Silent Disco Beats Kick-off' },
        { time: '11:00 PM', activity: 'Special Birthday Toast & Confetti Cannon Blast' },
        { time: '12:00 AM', activity: 'Late Night Gourmet Bites & Street Food' }
      ]
    },
    {
      id: 'evt-5',
      title: 'Acoustic Sunset: Indie Music & Food Truck Fest',
      category: 'concert',
      categoryLabel: 'Concerts & Music',
      date: '2026-11-08',
      time: '03:00 PM - 11:00 PM',
      location: 'Riverside Waterfront Park Amphitheater',
      city: 'Riverbend District',
      price: 49,
      priceLabel: '$49 / General Pass',
      image: 'https://images.unsplash.com/photo-1470225620780-dba8ba36b745?auto=format&fit=crop&w=800&q=80',
      badge: 'Trending Fest',
      badgeColor: 'badge-emerald',
      attendees: 1400,
      maxCapacity: 2000,
      organizer: 'SoundScape Productions & City Arts Council',
      featured: true,
      description: 'Six indie bands and acoustic singer-songwriters perform against the backdrop of the golden hour sunset. Accompanied by 18 craft breweries and gourmet food trucks.',
      highlights: [
        'Dual open-air stages with state-of-the-art acoustic tuning',
        'Eco-friendly festival with compostable ware and solar power stages',
        'Designers flea market featuring 30 local indie artisans',
        'Blanket & lawn-chair friendly family spaces'
      ],
      agenda: [
        { time: '03:00 PM', activity: 'Gates Open & Acoustic Busker Stages' },
        { time: '04:30 PM', activity: 'Folk & Indie Headliners Act 1' },
        { time: '06:15 PM', activity: 'Sunset Acoustic Jam Session' },
        { time: '08:30 PM', activity: 'Electric Headliner Band & Light Display' }
      ]
    },
    {
      id: 'evt-6',
      title: 'FutureHealth: International AI in Medicine Conference',
      category: 'conference',
      categoryLabel: 'Conferences',
      date: '2026-11-20',
      time: '09:00 AM - 05:00 PM',
      location: 'University Medical Sciences Complex',
      city: 'Biotech Quarter',
      price: 150,
      priceLabel: '$150 / Professional',
      image: 'https://images.unsplash.com/photo-1540575467063-178a50c2df87?auto=format&fit=crop&w=800&q=80',
      badge: 'Academic / CME',
      badgeColor: 'badge-blue',
      attendees: 380,
      maxCapacity: 500,
      organizer: 'International Medical Informatics Council',
      featured: false,
      description: 'Bridging healthcare practitioners, clinical researchers, and deep learning engineers to discuss breakthrough diagnostic AI models, robotic surgery systems, and patient data privacy.',
      highlights: [
        'CME accredited certification for medical attendees',
        'Peer-reviewed paper presentation track with digital proceedings',
        'Hands-on computer vision medical imaging workshops',
        'Poster sessions with research university grants'
      ],
      agenda: [
        { time: '09:00 AM', activity: 'Inaugural Address: The Next Decade of Diagnostic AI' },
        { time: '11:00 AM', activity: 'Clinical Trial Results & Peer Review Session' },
        { time: '01:00 PM', activity: 'Faculty & Researcher Networking Lunch' },
        { time: '02:30 PM', activity: 'Hands-on Medical Imaging Lab Work' }
      ]
    },
    {
      id: 'evt-7',
      title: 'Velvet Sky: Rooftop Sunset Jazz & Cocktail Soirée',
      category: 'private',
      categoryLabel: 'Private Parties',
      date: '2026-10-28',
      time: '06:00 PM - 11:30 PM',
      location: 'The Penthouse Terrace & Sky Lounge',
      city: 'Uptown Heights',
      price: 85,
      priceLabel: '$85 / guest',
      image: 'https://images.unsplash.com/photo-1533174072545-7a4b6ad7a6c3?auto=format&fit=crop&w=800&q=80',
      badge: 'Exclusive',
      badgeColor: 'badge-rose',
      attendees: 85,
      maxCapacity: 100,
      organizer: 'Signature Soirées Private Event Design',
      featured: false,
      description: 'An intimate, high-fashion evening beneath the skyline stars featuring a vintage jazz quintet, caviar and oyster bar, mixologist masterclasses, and ambient fireplace seating.',
      highlights: [
        'Signature smoked bourbon and botanical gin cocktail pairings',
        'Live performance by New Orleans style jazz quintet',
        'Stunning 360-degree panoramic city views at sunset',
        'Strict smart formal dress code with vintage flair'
      ],
      agenda: [
        { time: '06:00 PM', activity: 'Arrival & Welcome Bellinis at Sunset' },
        { time: '07:30 PM', activity: 'Hors d\'oeuvres & Live Jazz Quintet Set 1' },
        { time: '09:00 PM', activity: 'Mixologist Spotlight & Dessert Lounge' },
        { time: '10:30 PM', activity: 'Late Night Swing & Star-Gazing' }
      ]
    },
    {
      id: 'evt-8',
      title: 'Campus Cup: Inter-University Esports & Cultural Carnival',
      category: 'college',
      categoryLabel: 'College Events',
      date: '2026-11-25',
      time: '10:00 AM - 09:00 PM',
      location: 'Student Athletic Complex & Quadrangle',
      city: 'University Town',
      price: 0,
      priceLabel: 'Free Entry (Open to all colleges)',
      image: 'https://images.unsplash.com/photo-1511795409834-ef04bbd61622?auto=format&fit=crop&w=800&q=80',
      badge: 'College Fest',
      badgeColor: 'badge-purple',
      attendees: 800,
      maxCapacity: 1000,
      organizer: 'Inter-Collegiate Sports & Arts Council',
      featured: false,
      description: '3 days of thrilling esports showdowns (Valorant, Rocket League, FIFA) combined with inter-college dance face-offs, beatboxing battles, and culinary flea stalls.',
      highlights: [
        'Live broadcasted grand finals with tournament shoutcasters',
        'Inter-college group dance and battle of the bands',
        'Campus club pop-up stalls and street food village',
        'Custom trophy, medals, and university pride shields'
      ],
      agenda: [
        { time: '10:00 AM', activity: 'Carnival Parade & Opening Ceremony' },
        { time: '11:30 AM', activity: 'Esports Semifinals & Dance Prelims' },
        { time: '03:30 PM', activity: 'Battle of the Bands Main Stage' },
        { time: '07:00 PM', activity: 'Grand Finals Live Stadium Showdown & Trophy Presentation' }
      ]
    }
  ],

  // Platform Comparison Matrix for the College Experiment
  platforms: [
    {
      id: 'eventbrite',
      name: 'Eventbrite',
      tagline: 'Best for Public Discovery, Ticketing & Community Events',
      logoIcon: 'fa-ticket-simple',
      brandColor: '#F05537',
      bestFor: ['College Events', 'Concerts', 'Public Workshops', 'Festivals'],
      pricingModel: 'Free for free events. Paid: 3.7% + $1.79 per ticket + payment processing',
      freeTierAvailable: true,
      easeOfUse: 4.8,
      scalability: 4.5,
      features: {
        ticketing: 'Excellent - QR code check-in, tiered tickets, promo codes',
        rsvp: 'Very Good - automated confirmation emails and calendar invites',
        floorPlanning: 'Basic - General seating or simple assigned tables',
        networkingApp: 'Moderate - basic attendee app, lacks deep community chat',
        budgetTracking: 'Poor - Limited to revenue analytics, no expense planning',
        vendorManagement: 'Not Supported - Focused solely on ticketing and attendees',
        analytics: 'Strong ticket sales conversion and marketing attribution'
      },
      experimentAnalysis: {
        pros: [
          'High public discovery via Eventbrite marketplace SEO',
          'Completely free for college fests and non-profit free registrations',
          'Fast setup in under 10 minutes with seamless mobile app check-in',
          'Stripe/PayPal integration with reliable ticket fraud prevention'
        ],
        cons: [
          'High commission fees on expensive commercial tickets',
          'No vendor contracts, floor mapping, or budgeting tools',
          'Limited custom branding unless opting for enterprise tier'
        ],
        idealVerdict: 'The gold standard for college clubs, open mic nights, campus hackathons, and public concerts needing immediate online ticketing without setup fees.'
      },
      rating: 9.1
    },
    {
      id: 'cvent',
      name: 'Cvent',
      tagline: 'Enterprise Powerhouse for Corporate Summits & Expos',
      logoIcon: 'fa-building',
      brandColor: '#006699',
      bestFor: ['Corporate Conferences', 'Trade Shows', 'Global Summits', 'Medical Conventions'],
      pricingModel: 'Custom enterprise quote (Starting ~$3,000 - $15,000+ per year)',
      freeTierAvailable: false,
      easeOfUse: 3.4,
      scalability: 5.0,
      features: {
        ticketing: 'Enterprise - Multi-track passes, corporate billing, group badges',
        rsvp: 'Advanced - Customized approval workflows, VIP routing',
        floorPlanning: 'Outstanding - 3D interactive booth layout and venue CAD mapping',
        networkingApp: 'Comprehensive - Cvent Attendee Hub with 1-on-1 meeting scheduler',
        budgetTracking: 'Enterprise Grade - Full procurement, vendor RFPs, cost auditing',
        vendorManagement: 'Exceptional - RFP engine to negotiate hotel and convention rates',
        analytics: 'Full ROI tracking, session attendance heatmaps, lead capture'
      },
      experimentAnalysis: {
        pros: [
          'Unrivaled scalability for multi-day events with 10,000+ attendees',
          'Direct integration with Salesforce, Marketo, and enterprise ERPs',
          'Sophisticated venue sourcing engine (Cvent Supplier Network)',
          'High security compliance (SOC 2, GDPR, HIPAA compliant)'
        ],
        cons: [
          'Prohibitive cost for small businesses, weddings, or student groups',
          'Steep learning curve requiring dedicated staff training',
          'Requires annual contracts and lengthy onboarding'
        ],
        idealVerdict: 'Essential for multinational corporations and international medical/tech congresses managing complex logistics, hotel room blocks, and exhibitor booths.'
      },
      rating: 8.9
    },
    {
      id: 'whova',
      name: 'Whova',
      tagline: 'Top Rated for Academic Conferences, Hybrid Events & College Fests',
      logoIcon: 'fa-network-wired',
      brandColor: '#1790D2',
      bestFor: ['College Fests', 'Academic Conferences', 'Seminars', 'Alumni Meets'],
      pricingModel: 'Per-event pricing starting ~$799 - $1,500 based on attendee count',
      freeTierAvailable: false,
      easeOfUse: 4.6,
      scalability: 4.4,
      features: {
        ticketing: 'Very Good - Built-in registration with academic discount codes',
        rsvp: 'Strong - Instant badge generation and digital check-in',
        floorPlanning: 'Good - 2D interactive booth map and sponsor display',
        networkingApp: 'Industry Best - Community board, speed-networking, ice-breakers',
        budgetTracking: 'Moderate - Revenue tracking and sponsor tier ledger',
        vendorManagement: 'Moderate - Sponsor and speaker portal management',
        analytics: 'High engagement metrics, community chat analytics, session polls'
      },
      experimentAnalysis: {
        pros: [
          'Award-winning mobile app with highest attendee engagement rate',
          'Incredible community features: ride-sharing, lost & found, photo contests',
          'Dedicated speaker and paper submission management for academia',
          'Sponsor monetization banners and virtual booth tours'
        ],
        cons: [
          'Requires paid license even for academic events (though discounts apply)',
          'Not intended for wedding planning or private dining',
          'Less customizable UI compared to bespoke white-label solutions'
        ],
        idealVerdict: 'The champion platform for universities, collegiate tech symposiums, and research seminars where peer-to-peer networking and speaker management are paramount.'
      },
      rating: 9.3
    },
    {
      id: 'planningpod',
      name: 'Planning Pod',
      tagline: 'All-in-One Operating System for Wedding Planners & Venues',
      logoIcon: 'fa-ring',
      brandColor: '#7C3AED',
      bestFor: ['Weddings', 'Private Parties', 'Event Venues', 'Boutique Planners'],
      pricingModel: 'Monthly SaaS subscription ($59 - $199/month depending on event volume)',
      freeTierAvailable: false,
      easeOfUse: 4.4,
      scalability: 3.8,
      features: {
        ticketing: 'Moderate - RSVP portal and guest list tracking',
        rsvp: 'Excellent - Meal choice tracking, dietary restriction tallies, plus-ones',
        floorPlanning: 'Superb - Drag-and-drop table layouts, 3D room builder, seat assignments',
        networkingApp: 'Basic - Client collaboration portal rather than attendee app',
        budgetTracking: 'Top Tier - Detailed line-item budget, payment installments, quotes',
        vendorManagement: 'Outstanding - Vendor directory, contract signatures, contact logs',
        analytics: 'Planner profitability, guest check-in rates, budget variance'
      },
      experimentAnalysis: {
        pros: [
          'Purpose-built for wedding and party timelines (minute-by-minute rundown)',
          'Visual seating chart builder with round, banquet, and head table layouts',
          'Electronic signature for client contracts and invoice payment tracking',
          'Integrated vision board and file storage for floral & decor concepts'
        ],
        cons: [
          'Not built for large public ticket sales or conference tracks',
          'Requires monthly subscription fee for event coordinators',
          'No public event discovery marketplace'
        ],
        idealVerdict: 'The ultimate tool for professional wedding coordinators and private party hosts needing floor plans, vendor contracts, and precise budget breakdowns.'
      },
      rating: 8.8
    },
    {
      id: 'rsvpify',
      name: 'RSVPify',
      tagline: 'Modern, Elegant Online RSVPs & Seating for Celebrations',
      logoIcon: 'fa-envelope-open-text',
      brandColor: '#E11D48',
      bestFor: ['Weddings', 'Birthday Milestones', 'Private VIP Dinners', 'Fundraisers'],
      pricingModel: 'Freemium up to 100 RSVPs. Premium from $39 - $129/event',
      freeTierAvailable: true,
      easeOfUse: 4.9,
      scalability: 3.6,
      features: {
        ticketing: 'Good - Tiered tickets, donation collection, VIP passcodes',
        rsvp: 'Flawless - Custom questions, multi-event scheduling (Rehearsal + Reception)',
        floorPlanning: 'Very Good - Dynamic seating chart with drag & drop guest pins',
        networkingApp: 'Limited - Clean mobile check-in app for doormen/greeters',
        budgetTracking: 'Basic - Ticket sales tally and revenue summaries',
        vendorManagement: 'Not Supported - Focus is on guest experience and seating',
        analytics: 'Real-time open rates, RSVP accept/decline ratios, meal counts'
      },
      experimentAnalysis: {
        pros: [
          'Stunning design aesthetic with custom animations and font typography',
          'Secondary sub-events handling (e.g. VIP Pre-Party, After-Party invites)',
          'QR code digital check-in to eliminate paper guest rosters',
          'Generous free tier suitable for student milestone parties'
        ],
        cons: [
          'Lacks comprehensive vendor management or expense ledger',
          'Not suited for 5,000+ attendee corporate conventions',
          'Seating tool is 2D only'
        ],
        idealVerdict: 'Perfect for couples and social hosts wanting a high-end, aesthetic RSVP website with seating arrangements without learning complex software.'
      },
      rating: 9.0
    },
    {
      id: 'partyslate',
      name: 'PartySlate',
      tagline: 'Inspiration & Luxury Vendor Directory for High-End Events',
      logoIcon: 'fa-wand-magic-sparkles',
      brandColor: '#D97706',
      bestFor: ['Luxury Weddings', 'Celebrity Birthday Bashes', 'Gala Fundraisers'],
      pricingModel: 'Free for hosts to browse; Premium advertising subscription for vendors',
      freeTierAvailable: true,
      easeOfUse: 4.7,
      scalability: 3.5,
      features: {
        ticketing: 'Not Available - Directory and portfolio platform',
        rsvp: 'Not Supported - Connects hosts directly to verified planners and venues',
        floorPlanning: 'Gallery Only - Real photos of event decor and table setups',
        networkingApp: 'Not Supported - Client to vendor messaging',
        budgetTracking: 'Not Supported - Direct price requests to caterers and decorators',
        vendorManagement: 'Leading Directory - Thousands of reviewed photographers, florists',
        analytics: 'Vendor impression analytics and client inquiry metrics'
      },
      experimentAnalysis: {
        pros: [
          'Pinterest-like visual search for decor themes, floral arches, and lighting',
          'Credits every single vendor in real photo galleries (photographer, cake, DJ)',
          'Vetted directory of luxury event planners across major cities',
          'Great for creative ideation and conceptualizing theme boards'
        ],
        cons: [
          'Not an execution tool (no ticketing, no RSVP, no floor plan editor)',
          'Requires external software (like RSVPify or Eventbrite) for guest handling',
          'Vendor pricing tends toward higher-end and luxury budgets'
        ],
        idealVerdict: 'The premier discovery portal for brides, gala chairs, and milestone party planners looking for curated visual inspiration and top-tier local vendor contacts.'
      },
      rating: 8.6
    }
  ],

  // Platform Evaluation Criteria Weights for the Experiment Quiz
  quizCriteria: [
    {
      id: 'type',
      question: 'What type of event are you primarily planning?',
      options: [
        { label: 'College Event or Campus Fest', value: 'college', weight: { whova: 5, eventbrite: 4, rsvpify: 2, cvent: 1, planningpod: 1, partyslate: 1 } },
        { label: 'Wedding or Engagement Gala', value: 'wedding', weight: { planningpod: 5, rsvpify: 4, partyslate: 4, eventbrite: 1, whova: 0, cvent: 1 } },
        { label: 'Corporate Conference or Trade Expo', value: 'corporate', weight: { cvent: 5, whova: 4, eventbrite: 3, planningpod: 1, rsvpify: 2, partyslate: 0 } },
        { label: 'Birthday, Anniversary or Milestone Party', value: 'birthday', weight: { rsvpify: 5, eventbrite: 4, partyslate: 3, planningpod: 2, whova: 0, cvent: 0 } },
        { label: 'Live Concert or Music Festival', value: 'concert', weight: { eventbrite: 5, whova: 2, cvent: 2, rsvpify: 2, planningpod: 0, partyslate: 1 } }
      ]
    },
    {
      id: 'scale',
      question: 'What is your expected guest / attendee size?',
      options: [
        { label: 'Intimate Gathering (Under 50 guests)', value: 'small', weight: { rsvpify: 5, planningpod: 4, eventbrite: 3, partyslate: 3, whova: 1, cvent: 0 } },
        { label: 'Medium Crowd (50 to 300 guests)', value: 'medium', weight: { rsvpify: 4, planningpod: 4, eventbrite: 4, whova: 4, partyslate: 3, cvent: 2 } },
        { label: 'Large Festival / Conference (300 to 1,500+)', value: 'large', weight: { eventbrite: 5, whova: 5, cvent: 4, planningpod: 1, rsvpify: 2, partyslate: 1 } },
        { label: 'Mega Enterprise / Multi-City (1,500+ attendees)', value: 'enterprise', weight: { cvent: 6, eventbrite: 4, whova: 3, planningpod: 0, rsvpify: 0, partyslate: 0 } }
      ]
    },
    {
      id: 'priority',
      question: 'What is your single biggest requirement?',
      options: [
        { label: 'Zero Setup Cost & Fast Ticket Sales', value: 'cost', weight: { eventbrite: 5, rsvpify: 4, partyslate: 2, whova: 1, planningpod: 1, cvent: 0 } },
        { label: 'High Attendee Networking, Mobile App & Chat', value: 'networking', weight: { whova: 6, cvent: 4, eventbrite: 2, rsvpify: 1, planningpod: 1, partyslate: 0 } },
        { label: 'Seating Charts, Meal Tracking & Timelines', value: 'seating', weight: { planningpod: 5, rsvpify: 5, cvent: 3, eventbrite: 1, whova: 1, partyslate: 1 } },
        { label: 'Enterprise Security, RFPs & Custom Integrations', value: 'enterprise', weight: { cvent: 6, whova: 3, eventbrite: 3, planningpod: 1, rsvpify: 0, partyslate: 0 } },
        { label: 'Luxury Decor Inspiration & Vendor Finding', value: 'vendors', weight: { partyslate: 6, planningpod: 4, rsvpify: 2, eventbrite: 1, whova: 0, cvent: 0 } }
      ]
    }
  ],

  // Interactive Checklist Seed for Event Planner
  defaultChecklist: [
    { id: 'chk-1', stage: '2 Months Before', text: 'Define event goals, date, expected headcount, and target budget', done: true },
    { id: 'chk-2', stage: '2 Months Before', text: 'Shortlist venues, schedule site inspections, and negotiate quotes', done: true },
    { id: 'chk-3', stage: '2 Months Before', text: 'Choose the appropriate planning platform (e.g. Eventbrite, Whova, RSVPify)', done: true },
    { id: 'chk-4', stage: '1 Month Before', text: 'Confirm caterer, audiovisual rental, and photographer/videographer', done: false },
    { id: 'chk-5', stage: '1 Month Before', text: 'Launch event registration page or dispatch formal digital invitations', done: false },
    { id: 'chk-6', stage: '1 Month Before', text: 'Prepare schedule/run of show, speaker notes, and dietary requirement sheets', done: false },
    { id: 'chk-7', stage: '2 Weeks Before', text: 'Finalize seating chart, badge printing, and attendee headcount', done: false },
    { id: 'chk-8', stage: '2 Weeks Before', text: 'Conduct A/V technical rehearsal, microphone checks, and slide deck tests', done: false },
    { id: 'chk-9', stage: 'Day of Event', text: 'On-site briefing with staff, security, greeters, and setup crew', done: false },
    { id: 'chk-10', stage: 'Day of Event', text: 'Check-in gate setup, QR code scanner testing, and welcome kits placement', done: false },
    { id: 'chk-11', stage: 'Day of Event', text: 'Execute live run of show and capture photo/video milestones', done: false },
    { id: 'chk-12', stage: 'Post Event', text: 'Send thank-you survey, process vendor final payments, and archive analytics', done: false }
  ],

  // Default Budget Distribution Ratios
  budgetDistribution: {
    venue: 0.30,      // 30%
    catering: 0.30,   // 30%
    decor: 0.15,      // 15%
    avProduction: 0.10, // 10%
    marketing: 0.05,  // 5%
    staffing: 0.05,   // 5%
    contingency: 0.05 // 5%
  }
};

// Export to window
window.APP_DATA = APP_DATA;
